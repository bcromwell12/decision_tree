import pandas as pd
import numpy as np
from dataclasses import dataclass


@dataclass
class Node:
    """Node class for decision tree"""

    feature: str
    value: float
    left: "Node"
    right: "Node"
    label: str
